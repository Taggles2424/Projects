
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>

#include <iostream>

using namespace std;
using namespace cv;

int main()
{
    cout << "Hello World!" << endl;

    Mat image = imread("../test_image.jpg");

    // Check for failure
     if (image.empty())
     {
      cout << "Could not open or find the image" << endl;
      cin.get(); //wait for any key press
      return -1;
     }

     String windowName = "AAU"; //Name of the window

     namedWindow(windowName); // Create a window

     imshow(windowName, image); // Show our image inside the created window.

     waitKey(0); // Wait for any keystroke in the window

     destroyWindow(windowName); //destroy the created window


    return 0;
}
